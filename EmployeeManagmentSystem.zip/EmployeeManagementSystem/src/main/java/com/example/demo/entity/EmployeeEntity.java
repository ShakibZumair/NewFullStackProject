package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
//@AllArgsConstructor
@Entity
@Table(name = "employees")
public class EmployeeEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	long id;
	@Column(name = "first_name")
	String firstName;
	@Column(name = "last_name")
	String lastName;
	@Column(name = "middle_name")
	String middleName;
	@Column(name = "email_id")
	String emailId;
	@Column(name = "mobile_number")
	String mobileNumber;

	String password;
	@Column(name = "permanent_address")
	String permanentAddress;
	@Column(name = "corresponding_address")
	String correspondingAddress;
	String city;
	int pincode;
	String state;
	String country;
	@Column(name = "current_role")
	String currentRole;
	@Column(name = "last_organization")
	String lastOrganization;
	@Column(name = "emergency_contact_number")
	String emergencyContactNumber;
    float currentCTC;
	@Column(name = "year_of_experience")
	float yearOfExperience;
	float salary;

}
