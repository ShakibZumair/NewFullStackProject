package com.example.demo.model;

import javax.persistence.Column;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Employee {

	long id;
	String firstName;
	String lastName;
	String middleName;
	String emailId;
	String mobileNumber;	
	String password;
	String permanentAddress;
	String correspondingAddress;
	String city;
	int pincode;
	String state;
	String country;
	String currentRole;
	String lastOrganization;
	String emergencyContactNumber;
	float currentCTC;
	float yearOfExperience;
	float salary;

}
