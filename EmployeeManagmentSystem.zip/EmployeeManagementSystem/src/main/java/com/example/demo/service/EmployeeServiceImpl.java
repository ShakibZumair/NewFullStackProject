package com.example.demo.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.entity.EmployeeEntity;
import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeRepository employeerepository;

	
//	@Override
//	public Employee loginEmployee( Employee employee)  {
//		EmployeeEntity employeeEntity = null;
//		BeanUtils.copyProperties(employee, employeeEntity);
//		
//		String temailId = employee.getEmailId();
//		
//		String tpassword = employee.getPassword();
//
//		if (temailId != null && tpassword != null) {
//
//	         employeeEntity = employeerepository.findByEmailIdAndPassword(temailId, tpassword);
//
//			
//		}

//		if (employeeEntity == null) {
//
//			throw new Exception("Invalide Credentials");
//			// ResponseEntity.badRequest();
//		}

//		return employee;

//	}

//	public Employee registerNewEmployee(@RequestBody Employee employee) throws Exception {
//
//		String tempEmailId = employee.getEmailId();
//		
//
//		if (tempEmailId != null && !"".equals(tempEmailId)) {
//
//			Employee empobj = employeeRepository.findByEmailId(tempEmailId);
//
//			if (empobj != null) {
//				try {
//					throw new Exception("User with" + tempEmailId + "is already Exists");
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		}
//
//		Employee empobj = null;
//		
////		employee.setPassword(this.bCryptPasswordEncoder.encode(employee.getPassword()));
//
//		empobj = saveEmployee(employee);
//		return empobj;
//	}
	
	@Override
	public Employee createEmployee(Employee employee) {
		// TODO Auto-generated method stub
		EmployeeEntity employeeEntity = new EmployeeEntity();
		BeanUtils.copyProperties(employee, employeeEntity);
		employeerepository.save(employeeEntity);
		return employee;
	}

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		List<EmployeeEntity> employeeEntities=employeerepository.findAll();
		List<Employee> employees=employeeEntities.stream().map(emp->new Employee(
				emp.getId(),
				emp.getFirstName(),
				emp.getLastName(),
				emp.getMiddleName(),
				emp.getEmailId(),
				emp.getMobileNumber(),
				emp.getPassword(),
				emp.getPermanentAddress(),
				emp.getCorrespondingAddress(),
				emp.getCity(),
				emp.getPincode(),
				emp.getState(),
				emp.getCountry(),
				emp.getCurrentRole(),
				emp.getLastOrganization(),
				emp.getEmergencyContactNumber(),
				emp.getCurrentCTC(),
				emp.getYearOfExperience(),
				emp.getSalary()
				)).collect(Collectors.toList());
		
		return employees;
	
	}

	@Override
	public boolean deleteEmployee(long id) {
		// TODO Auto-generated method stub
		EmployeeEntity employeeEntity=employeerepository.findById(id).get();
		employeerepository.delete(employeeEntity);
		
		return true;
	}

	@Override
	public Employee getEmployeeById(long id) {
		// TODO Auto-generated method stub
		EmployeeEntity employeeEntity=employeerepository.findById(id).get();
		Employee employee=new Employee();
		BeanUtils.copyProperties(employeeEntity, employee);
		return employee;
	}

	@Override
	public Employee updateEmployee(long id, Employee employee) {
		// TODO Auto-generated method stub
		EmployeeEntity employeeEntity=employeerepository.findById(id).get();
		employeeEntity.setFirstName(employee.getFirstName());
		employeeEntity.setLastName(employee.getLastName());
		employeeEntity.setMiddleName(employee.getMiddleName());
		employeeEntity.setEmailId(employee.getEmailId());
		employeeEntity.setMobileNumber(employee.getMobileNumber());
		employeeEntity.setPassword(employee.getPassword());
		employeeEntity.setPermanentAddress(employee.getPermanentAddress());
		employeeEntity.setCorrespondingAddress(employee.getCorrespondingAddress());
		employeeEntity.setCity(employee.getCity());
		employeeEntity.setPincode(employee.getPincode());
		employeeEntity.setState(employee.getState());
		employeeEntity.setCountry(employee.getCountry());
		employeeEntity.setCurrentRole(employee.getCurrentRole());
		employeeEntity.setLastOrganization(employee.getLastOrganization());
		employeeEntity.setEmergencyContactNumber(employee.getEmergencyContactNumber());
		employeeEntity.setCurrentCTC(employee.getCurrentCTC());
		employeeEntity.setYearOfExperience(employee.getYearOfExperience());
		employeeEntity.setSalary(employee.getSalary());
		return employee;
		
	}




}
