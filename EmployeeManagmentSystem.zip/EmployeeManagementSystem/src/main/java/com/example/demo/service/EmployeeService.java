package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Employee;

public interface EmployeeService {

	Employee createEmployee (Employee employee);
	List<Employee> getAllEmployee();
	boolean deleteEmployee(long id);
	Employee getEmployeeById (long id);
	Employee updateEmployee(long id, Employee employee);
//	public Employee loginEmployee(Employee employee);

}
