package com.example.demo.exception;

public class InvalidCreadential extends RuntimeException {

	public InvalidCreadential(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

}
