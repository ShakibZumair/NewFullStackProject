package com.example.demo.model;

import javax.persistence.CascadeType;
import javax.persistence.OneToOne;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.entity.AddressEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Employee {

	long id;
	String firstName;
	String lastName;
	String middleName;
	String emailId;
	String mobileNumber;
	String password;
	
	String currentRole;
	String lastOrganization;
	String emergencyContactNumber;
	float currentCTC;
	float yearOfExperience;
	float salary;
	
	//@OneToOne(targetEntity = Address.class, cascade = CascadeType.ALL)
	
	@Autowired
	Address address;
}
